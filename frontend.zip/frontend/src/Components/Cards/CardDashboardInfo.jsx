import React from 'react';

export default function CardDashboardInfo() {
    const [isLoading, setIsLoading] = React.useState(true);
    const [info, setInfo] = React.useState(String);

    React.useEffect(() => {
        fetch('/api/admin/info', {
            credentials: 'include'
        })
            .then(response => response.json())
            .then(json => {
                setInfo(json);
                setIsLoading(false);
            });
        setInterval(function () {
            fetch('/api/admin/info', {
                credentials: 'include'
            })
                .then(response => response.json())
                .then(json => {
                    setInfo(json);
                    setIsLoading(false);
                });
        }, 1000);
    }, []);

    return (
        <>
            <div className="col-xl-4 col-lg-5">
                            <div className="card shadow mb-4">
                                <div
                                    className="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 className="m-0 font-weight-bold text-primary">儀表板資訊</h6>
                                    
                                </div>
                                <div className="card-body">
                                {isLoading ? <h3 className="text-center">載入中</h3> :
                    <>
                    <p>儀表板版本： {info.version}</p>
                    <p>處理程序 ID： {info.pid}</p>
                    <p>儀表板記憶體使用量： {info.dashactylStats.ram}MB</p>
                    <p>儀表板 CPU 使用率： {info.dashactylStats.cpu}%</p>
                    <p>儀表板運行時間： {info.dashactylStats.uptime}</p>
                    </>
}
                                </div>
                            </div>
                        </div>

                        <div className="col-xl-4 col-lg-5">
                            <div className="card shadow mb-4">
                                <div
                                    className="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 className="m-0 font-weight-bold text-primary">系統資訊</h6>
                                    
                                </div>
                                <div className="card-body">
                                {isLoading ? <h3 className="text-center">載入中</h3> :
                    <>
                    <p>系統 CPU 型號： {info.systemInfo.cpu_model}</p>
                    <p>系統平台： {info.systemInfo.platform}</p>
                    <p>系統運行時間： {info.systemInfo.uptime}</p>
                    <p>系統記憶體使用量： {info.systemInfo.usedRam}/{info.systemInfo.totalRam}MB</p>
                    <p>系統 CPU 使用率： {info.systemInfo.cpuUsage}%</p>
                    </>
}
                                </div>
                            </div>
                        </div>
        </>
    );
}
