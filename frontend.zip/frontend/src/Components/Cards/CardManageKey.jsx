import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import 'sweetalert2/dist/sweetalert2.min.css';

const MySwal = withReactContent(Swal);

import { toast } from 'react-toastify'

export default function CardManageServer() {
	const [isLoading, setIsLoading] = React.useState(true);
    const [key, setKey] = React.useState(String)

	const params = useParams();
	const navigate = useNavigate();

	React.useEffect(() => {
		fetch(`/api/admin/keys/get/${params.key}`, {
			credentials: 'include'
		})
			.then(response => response.json())
			.then(json => {
				if (json.error) return MySwal.fire({
					icon: 'error',
					title: '錯誤',
					text: json.error,
				}).then(() => {
					navigate('/dashboard');
				});
				if (!json.key) return MySwal.fire({
					icon: 'error',
					title: '錯誤',
					text: "找不到金鑰。",
				}).then(() => {
					navigate('/dashboard/admin');
				});
				setKey(json.key);
                setIsLoading(false)
			});
	}, []);

	const deleteApiKey = () => {
		const deleteApiKeyPromise = new Promise(async (resolve, reject) => {
			fetch(`/api/admin/keys/delete/${params.key}`, {
				method: 'delete',
				credentials: 'include'
			})
				.then(response => response.json())
				.then(json => {
					if (json.error) {
						reject(json.error)
						return MySwal.fire({
							icon: 'error',
							title: '錯誤',
							text: json.error,
						});
					}
					if (json.success) {
						resolve()
						return MySwal.fire({
							icon: 'success',
							title: '成功！',
							text: 'API 金鑰已刪除！',
						}).then(() => {
							return navigate('/dashboard/admin');
						});
					}
				});
		})
		toast.promise(
			deleteApiKeyPromise,
			{
				pending: '正在刪除 API 金鑰...',
				success: 'API 金鑰已刪除！',
				error: {
					render({ data }) {
						return <a>{data}</a>
					}
				}
			}
		)
	};

	return (
		<>
		<div className="col-xl-12">
                    <div className="card">
                                <div
                                    className="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 className="m-0 font-weight-bold text-primary">API 金鑰資訊</h6>
                                </div>
                        <div className="card-body">
						{isLoading ? <h3>載入中</h3> :
                            <form>
                                <div className="form-group">
                                    <label htmlFor="serverName">API 金鑰</label>
                                    <input type="text" className="form-control form-control-alternative"
                                        placeholder={key.key} id="name" disabled/>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="serverMemory">描述</label>
									<input type="text" className="form-control form-control-alternative"
                                        placeholder={key.description} id="ram" disabled/>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="serverDisk">最後使用</label>
                                    <input type="text" className="form-control form-control-alternative"
                                        placeholder={key.last_used} id="disk" disabled/>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="serverCPU">建立於</label>
                                    <input type="text" className="form-control form-control-alternative"
                                        placeholder={key.created} id="cpu" disabled/>
                                </div>
	<button onClick={deleteApiKey} type="button" className="btn btn-danger me-2">刪除</button>
                            </form>
}
                        </div>
                    </div>
                </div>
		</>
	);
}
