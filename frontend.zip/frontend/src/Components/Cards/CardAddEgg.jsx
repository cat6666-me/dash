import React from 'react';
import AddEgg from '../../Api/AddEgg';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import 'sweetalert2/dist/sweetalert2.min.css';

const MySwal = withReactContent(Swal);



export default function CardAddEgg() {
	const addEggForm = (event) => {
		AddEgg(event).then(data => {
			if (data.success) return MySwal.fire({
				icon: 'success',
				title: '成功！',
				text: 'Egg 已成功新增至資料庫。',
			}).then(() => {
				document.getElementById('addEggForm').reset();
			});
			if (data.error) MySwal.fire({
				icon: 'error',
				title: '錯誤',
				text: data.error,
			});
		});
	};
	return (
		<>
			<div className="col-xl-12">
                    <div className="card">
                                <div
                                    className="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 className="m-0 font-weight-bold text-primary">新增 Egg</h6>
                                </div>
                        <div className="card-body">
						<form onSubmit={addEggForm} id="addEggForm">
                    <div className="form-group">
                      <label htmlFor="name">Egg 名稱</label>
                      <input type="text" className="form-control" name="name" id="name" placeholder=" " required/>
                    </div>
                    <div className="form-group">
                      <label htmlFor="egg_id">Egg ID</label>
                      <input type="text" className="form-control" name="egg_id" id="egg_id" placeholder=" " required/>
                    </div>
                    <div className="form-group">
                      <label htmlFor="egg_docker_image">Egg Docker 映像檔</label>
                      <input defaultValue="quay.io/pterodactyl/core:java" type="text" className="form-control" name="egg_docker_image" id="egg_docker_image" required/>
                    </div>
                    <div className="form-group">
                      <label htmlFor="egg_startup">Egg 啟動命令</label>
                      <input defaultValue="java -Xms128M -Xmx{{SERVER_MEMORY}}M -Dterminal.jline=false -Dterminal.ansi=true -jar {{SERVER_JARFILE}}" type="text" className="form-control" name="egg_startup" id="egg_startup" required/>
                    </div>
					<div className="form-group">
                      <label htmlFor="egg_databases">資料庫數量</label>
                      <input type="text" className="form-control" name="egg_databases" id="egg_databases" placeholder=" " required/>
                    </div>
					<div className="form-group">
                      <label htmlFor="egg_backups">備份數量</label>
                      <input type="text" className="form-control" name="egg_backups" id="egg_backups" placeholder=" " required/>
                    </div>
					<div className="form-group">
                      <label htmlFor="egg_environment">環境變數</label>
                      <input defaultValue='{ "SERVER_JARFILE": "server.jar", "BUILD_NUMBER": "latest" }' type="text" className="form-control" name="egg_environment" id="egg_environment" required/>
                    </div>
					<button type="submit" className="btn btn-primary me-2">繼續</button>
                  </form>
                        </div>
                    </div>
                </div>
		</>
	);
}
