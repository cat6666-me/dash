import React from 'react';

export default function CardAfk({ isConnected, coins, time }) {
	const [isLoading, setIsLoading] = React.useState(true);
	const [afkInterval, setAfkInterval] = React.useState(null);
	const [afkCoins, setAfkCoins] = React.useState(null);

	React.useEffect(() => {
		fetch('/api/afk', {
			credentials: 'include'
		})
			.then(response => response.json())
			.then(json => {
				setAfkInterval(json.afk_interval);
				setAfkCoins(json.afk_coins);
				setIsLoading(false);
			});
	}), [];

	return (
		<>
			<div className="col-xl-12">
                    <div className="card">
                        <div className="card-body">
						<h3 className="text-center"><b>歡迎來到掛機頁面</b></h3>
                  <hr/>
                  <p className="text-center"><b>保持掛機狀態以賺取硬幣。</b></p>
                   <hr/>
                   <div id="afk_main">
				   <p className="text-center"><b>Websocket 狀態：{isConnected ? <a className="text-green-500">已連接</a> : <a className="text-red-500">已斷開</a>}</b></p>
                    <p className="text-center"><b>每 {afkInterval} 秒，您將賺取 {afkCoins} 個硬幣。</b></p>
                    <p className="text-center"><b>您已掛機：  {time} 秒。</b></p>
                    <p className="text-center"><b>您目前已獲得 {coins} 個硬幣。</b></p>
                  </div>
                        </div>
                    </div>
                </div>
		</>
	);
}
