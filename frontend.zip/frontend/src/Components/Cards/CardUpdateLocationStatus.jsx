import React from 'react';
import UpdateLocationStatus from '../../Api/UpdateLocationStatus';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import 'sweetalert2/dist/sweetalert2.min.css';

const MySwal = withReactContent(Swal);

export default function CardUpdateLocationStatus() {
	const [isLoading, setIsLoading] = React.useState(true);
	const [locations, setLocations] = React.useState(String);

	React.useEffect(() => {
		fetch('/api/admin/location/get/all', {
			credentials: 'include'
		})
			.then(response => response.json())
			.then(json => {
				setLocations(json);
				setIsLoading(false);
			});
	}, []);

	const updateLocationStatusForm = (event) => {
		UpdateLocationStatus(event).then(data => {
			if (data.success) return MySwal.fire({
				icon: 'success',
				title: '成功！',
				text: 'Location 已更新。',
			}).then(() => {
				document.getElementById('updateLocationStatusForm').reset();
				fetch('/api/admin/location/get/all', {
					credentials: 'include'
				})
					.then(response => response.json())
					.then(json => {
						setLocations(json);
						setIsLoading(false);
					});
			});
			if (data.error) MySwal.fire({
				icon: 'error',
				title: '錯誤',
				text: data.error,
			});
		});
	};
	return (
		<>
			  <div className="col-xl-4 col-lg-5">
                            <div className="card shadow mb-4">
                                <div
                                    className="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 className="m-0 font-weight-bold text-primary">更新 Location 狀態</h6>
                                    
                                </div>
                                <div className="card-body">
                                {isLoading ? <h3 className="text-center">載入中</h3> :
					<form id="updateLocationStatusForm" onSubmit={updateLocationStatusForm}>
					<div className="form-group">
                      <label htmlFor="location">Location</label>
                      <select className="form-control form-control-lg" id="location" name="location">
					  {locations.map((location) =>
						<option value={location.id}>{location.name} - 目前已啟用： {location.enabled.toString()}</option>
					)}
                      </select>
                    </div>
					<div className="form-group">
                      <label htmlFor="status">狀態</label>
                      <select className="form-control form-control-lg" id="status" name="status">
					  <option>true</option>
					  <option>false</option>
                      </select>
                    </div>
					<button type="submit" className="btn btn-primary me-2">繼續</button>
                    </form>
}
                                </div>
                            </div>
                        </div>


						<div className="col-xl-4 col-lg-5">
                            <div className="card shadow mb-4">
                                <div
                                    className="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 className="m-0 font-weight-bold text-primary">小彩蛋 哈哈</h6>
                                    
                                </div>
                                <div className="card-body">
                                <p className="text-center">嘿，感謝您下載 SB-Admin 2 主題</p>
					<p className="text-center">加入我的 Discord 伺服器以獲取更多類似的主題</p>
					<p className="text-center"><a href="https://discord.gg/McFr2jwNSE">https://discord.gg/McFr2jwNSE</a></p>
					<p className="text-center">希望您會喜歡 :3</p>
                                </div>
                            </div>
                        </div>
		</>
	);
}
