import React from 'react';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import 'sweetalert2/dist/sweetalert2.min.css';

const MySwal = withReactContent(Swal);

export default function CardAccountInfo() {
	const [isLoading, setIsLoading] = React.useState(true);
	const [discordInvite, setDiscordInvite] = React.useState(String);
	const [pterodactylURL, setPterodactylURL] = React.useState(String);
	const [user, setUser] = React.useState(String);

	React.useEffect(() => {
		fetch('/api/dashboard-info', {
			credentials: 'include'
		})
			.then(response => response.json())
			.then(json => {
				setDiscordInvite(json.discord_invite);
				setPterodactylURL(json.pterodactyl_url);
				fetch('/api/me', {
					credentials: 'include'
				})
					.then(response => response.json())
					.then(json => {
						setUser(json.ptero_user);
						setIsLoading(false);
					});
			});
	}, []);

	const openPanel = () => {
		window.open(pterodactylURL);
	}

	const openDiscord = () => {
		window.open(discordInvite);
	}

	const resetPassword = () => {
		fetch('/api/reset-password', {
			method: 'post',
			credentials: 'include'
		})
			.then(response => response.json())
			.then(json => {
				MySwal.fire({
					icon: 'info',
					title: '新密碼',
					text: `您登入面板和用戶區域的新密碼為：${json.password}。請記下並妥善保存。`,
				})
			});
	}

	return (
		<>
		  <div className="col-xl-4 col-lg-5">
                            <div className="card shadow mb-4">
                                <div
                                    className="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 className="m-0 font-weight-bold text-primary">登入資訊</h6>
                                    
                                </div>
                                <div className="card-body">
                                    <input type="text" className="form-control form-control-user"
                                            placeholder={isLoading ? <>載入中</>
											: user.attributes.email } disabled/>
                                            <hr/>
											{isLoading ? <button type="button" onClick={resetPassword} className="btn btn-primary btn-user btn-block" disabled>
                                                重設密碼
                                            </button>
					  : <button type="button" onClick={resetPassword} className="btn btn-primary btn-user btn-block">
					  重設密碼
				  </button> }
					  {isLoading ? <button type="button" onClick={openPanel} className="btn btn-primary btn-user btn-block" disabled>
                                                遊戲面板
                                            </button>
					  : <button type="button" onClick={openPanel} className="btn btn-primary btn-user btn-block">
					  遊戲面板
				  </button> }
					  {isLoading ? <button type="button" onClick={openDiscord} className="btn btn-primary btn-user btn-block" disabled>
                                                Discord 伺服器
                                            </button>
					  :<button type="button" onClick={openDiscord} className="btn btn-primary btn-user btn-block">
					  Discord 伺服器
				  </button> }
                                </div>
                            </div>
                        </div>
		</>
	);
}
