import React from 'react';
import AddPackage from '../../Api/AddPackage';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import 'sweetalert2/dist/sweetalert2.min.css';

const MySwal = withReactContent(Swal);



export default function CardAddPackage() {
	const addPackageForm = (event) => {
		AddPackage(event).then(data => {
			if (data.success) return MySwal.fire({
				icon: 'success',
				title: '成功！',
				text: 'Package 已成功新增至資料庫。',
			}).then(() => {
				document.getElementById('addPackageForm').reset();
			});
			if (data.error) MySwal.fire({
				icon: 'error',
				title: '錯誤',
				text: data.error,
			});
		});
	};
	return (
		<>
		<div className="row">
			<div className="col-xl-12">
                    <div className="card">
                                <div
                                    className="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 className="m-0 font-weight-bold text-primary">新增 Package</h6>
                                </div>
                        <div className="card-body">
						<form onSubmit={addPackageForm} id="addPackageForm">
                    <div className="form-group">
                      <label htmlFor="name">Package 名稱</label>
                      <input type="text" className="form-control" name="name" id="name" placeholder=" " required/>
                    </div>
                    <div className="form-group">
                      <label htmlFor="memory">記憶體</label>
                      <input type="text" className="form-control" name="ram" id="ram" placeholder=" " required/>
                    </div>
                    <div className="form-group">
                      <label htmlFor="disk">Disk</label>
                      <input type="text" className="form-control" name="disk" id="disk" placeholder=" " required/>
                    </div>
                    <div className="form-group">
                      <label htmlFor="cpu">CPU</label>
                      <input type="text" className="form-control" name="cpu" id="cpu" placeholder=" " required/>
                    </div>
					<div className="form-group">
                      <label htmlFor="price">價格</label>
                      <input type="text" className="form-control" name="price" id="price" placeholder=" " required/>
                    </div>
                    <div className="form-group">
                      <label htmlFor="renewal_enabled">啟用續約</label>
                      <select className="form-control" id="renewal_enabled" name="renewal_enabled">
					  <option>true</option>
					  <option>false</option>
                      </select>
                    </div>
					<div className="form-group">
                      <label htmlFor="renewal_time">續約時間 (毫秒)</label>
                      <input type="text" className="form-control" name="renewal_time" id="renewal_time" placeholder=" " required/>
                    </div>
					<div className="form-group">
                      <label htmlFor="renewal_price">續約價格</label>
                      <input type="text" className="form-control" name="renewal_price" id="renewal_price" placeholder=" " required/>
                    </div>
					<button type="submit" className="btn btn-primary me-2">繼續</button>
                  </form>
                        </div>
                    </div>
                </div>
				</div>
		</>
	);
}
