import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import 'sweetalert2/dist/sweetalert2.min.css';

const MySwal = withReactContent(Swal);

import { toast } from 'react-toastify'

export default function CardManageServer() {
	const [isLoading, setIsLoading] = React.useState(true);
	const [server, setServer] = React.useState(String);
	const [pterodactylUrl, setPterodactylUrl] = React.useState(String);
	const [renewal, setRenewal] = React.useState(String);
	const [renewalCost, setRenewalCost] = React.useState(String);
	const [renewalEnabled, setRenewalEnabled] = React.useState(String);

	const params = useParams();
	const navigate = useNavigate();

	React.useEffect(() => {
		fetch(`/api/server/get/${params.id}`, {
			credentials: 'include'
		})
			.then(response => response.json())
			.then(json => {
				if (json.error) return MySwal.fire({
					icon: 'error',
					title: '錯誤',
					text: json.error,
				}).then(() => {
					navigate('/dashboard');
				});
				setServer(json.server);
				fetch('/api/dashboard-info', {
					credentials: 'include'
				})
					.then(response => response.json())
					.then(json => {
						if (json.error) return MySwal.fire({
							icon: 'error',
							title: '錯誤',
							text: json.error,
						});
						setPterodactylUrl(json.pterodactyl_url);
						fetch(`/api/renew/get/${params.id}`, {
							credentials: 'include'
						})
							.then(response => response.json())
							.then(json => {
								if (json.error) return MySwal.fire({
									icon: 'error',
									title: '錯誤',
									text: json.error,
								});
								const timestamp = new Date(json.renewal.renew_by);
								const date = new Intl.DateTimeFormat('en-UK', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(timestamp);
								setRenewal(date);
								setRenewalCost(json.renewal.renew_cost);
								setRenewalEnabled(json.renewal.renewal_enabled);
								setIsLoading(false);
							});
					});
			});
	}, []);

	const redirect = () => {
		window.open(`${pterodactylUrl}/server/${server.attributes.identifier}`);
	};

	const renewServer = () => {
		MySwal.fire({
			title: '您確定要執行此操作嗎？',
			text: `這將花費您 ${renewalCost} 個硬幣。`,
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: '是'
		}).then((result) => {
			if (result.isConfirmed) {
				fetch(`/api/renew/${params.id}`, {
					method: 'post',
					credentials: 'include'
				})
					.then(response => response.json())
					.then(json => {
						if (json.error) return MySwal.fire({
							icon: 'error',
							title: '錯誤',
							text: json.error,
						});
						if (json.success) {
							fetch(`/api/renew/get/${params.id}`, {
								credentials: 'include'
							})
								.then(response => response.json())
								.then(json => {
									if (json.error) return MySwal.fire({
										icon: 'error',
										title: '錯誤',
										text: json.error,
									});
									const timestamp = new Date(json.renewal.renew_by);
									const date = new Intl.DateTimeFormat('en-UK', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(timestamp);
									setRenewal(date);
									setRenewalCost(json.renewal.renew_cost);
									setRenewalEnabled(json.renewal.renewal_enabled);
								});
							return MySwal.fire({
								icon: 'success',
								title: '成功！',
								text: '伺服器已續約！',
							});
						}
					});
			}
		});
	};

	const deleteServer = () => {
		MySwal.fire({
			title: '您確定要執行此操作嗎？',
			text: `您將無法復原此操作！`,
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: '是'
		}).then((result) => {
			if (result.isConfirmed) {
				const deleteServerPromise = new Promise(async (resolve, reject) => {
					fetch(`/api/server/delete/${params.id}`, {
						method: 'delete',
						credentials: 'include'
					})
						.then(response => response.json())
						.then(json => {
							if (json.error) {
								reject(json.error)
								return MySwal.fire({
									icon: 'error',
									title: '錯誤',
									text: json.error,
								});
							}
							if (json.success) {
								resolve()
								return MySwal.fire({
									icon: 'success',
									title: '成功！',
									text: '伺服器已刪除！',
								}).then(() => {
									return navigate('/dashboard');
								});
							}
						});
				})
				toast.promise(
					deleteServerPromise,
					{
						pending: '正在刪除伺服器...',
						success: '伺服器已刪除！',
						error: {
							render({ data }) {
								return <a>{data}</a>
							}
						}
					}
				)
			}
		});
	};

	return (
		<>
		<div className="col-xl-12">
                    <div className="card">
                                <div
                                    className="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 className="m-0 font-weight-bold text-primary">伺服器資訊</h6>
                                </div>
                        <div className="card-body">
						{isLoading ? <h3>載入中</h3> :
                            <form>
                                <div className="form-group">
                                    <label htmlFor="serverName">伺服器名稱</label>
                                    <input type="text" className="form-control form-control-alternative"
                                        placeholder={server.attributes.name} id="name" disabled/>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="serverMemory">記憶體</label>
									<input type="text" className="form-control form-control-alternative"
                                        placeholder={server.attributes.limits.memory} id="ram" disabled/>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="serverDisk">磁碟</label>
                                    <input type="text" className="form-control form-control-alternative"
                                        placeholder={server.attributes.limits.disk} id="disk" disabled/>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="serverCPU">CPU</label>
                                    <input type="text" className="form-control form-control-alternative"
                                        placeholder={server.attributes.limits.cpu} id="cpu" disabled/>
                                </div>
								{renewalEnabled ?
										<>
										<div className="form-group">
                                    <label htmlFor="renewby">續約期限</label>
                                    <input type="text" className="form-control form-control-alternative"
                                        placeholder={renewal} id="renewby" disabled/>
                                </div>
								<div className="form-group">
                                    <label htmlFor="renewcost">續約成本</label>
                                    <input type="text" className="form-control form-control-alternative"
                                        placeholder={renewalCost} id="renewcost" disabled/>
                                </div>
										</>
										:
										<></>
					}
					<button onClick={redirect} type="button" className="btn btn-success me-2">查看</button>
	{renewalEnabled ?
	<button onClick={renewServer} type="button" className="btn btn-success me-2">伺服器續約</button> :
										<></>
	}
	<button onClick={deleteServer} type="button" className="btn btn-danger me-2">刪除伺服器</button>

                            </form>
}
                        </div>
                    </div>
                </div>
		</>
	);
}
