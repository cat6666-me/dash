import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import CreateServer from '../../Api/CreateServer';
import 'sweetalert2/dist/sweetalert2.min.css';

const MySwal = withReactContent(Swal);

import { toast } from 'react-toastify'



export default function CardCreateServer() {
	const [isLoading, setIsLoading] = React.useState(true);
	const [eggs, setEggs] = React.useState(String);
	const [locations, setLocations] = React.useState(String);

	const navigate = useNavigate();

	React.useEffect(() => {
		fetch('/api/admin/egg/get/all', {
			credentials: 'include'
		})
			.then(response => response.json())
			.then(json => {
				setEggs(json);
				fetch('/api/admin/location/get/all', {
					credentials: 'include'
				})
					.then(response => response.json())
					.then(json => {
						setLocations(json);
						setIsLoading(false);
					});
			});
	}, []);

	const createServer = (event) => {
		const createServerPromise = new Promise(async (resolve, reject) => {
			CreateServer(event).then(data => {
				if (data.success) {
					resolve()
					return MySwal.fire({
						icon: 'success',
						title: '成功！',
						text: '伺服器已建立！',
					}).then(() => {
						return navigate('/dashboard');
					});
				}
				if (data.error) {
					reject(data.error)
					return MySwal.fire({
						icon: 'error',
						title: '錯誤',
						text: data.error,
					});
				}
			});
		})
		toast.promise(
			createServerPromise,
			{
				pending: '正在建立伺服器...',
				success: '伺服器已建立！',
				error: {
					render({ data }) {
						return <a>{data}</a>
					}
				}
			}
		)
	};

	return (
		<>
			<div className="col-xl-12">
                    <div className="card">
                                <div
                                    className="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 className="m-0 font-weight-bold text-primary">建立新伺服器</h6>
                                </div>
                        <div className="card-body">
						{isLoading ? <p className="text-center"><b>載入中</b></p>
				   :
				   <form onSubmit={createServer} id="installForm">
                                <div className="form-group">
                                    <label htmlFor="name">名稱</label>
                                    <input type="text" className="form-control form-control-alternative"
                                        name="name" id="name" placeholder=" " required/>
                                </div>
								<div className="form-group">
                                    <label htmlFor="memory">分配的記憶體</label>
                                    <input type="text" className="form-control form-control-alternative" name="ram" id="ram" placeholder=" " required/>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="disk">分配的磁碟</label>
                                    <input type="text" className="form-control form-control-alternative" name="disk" id="disk" placeholder=" " required/>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="cpu">分配的 CPU</label>
                                    <input type="text" className="form-control form-control-alternative" name="cpu" id="cpu" placeholder=" " required/>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="location">伺服器位置</label>
                                    <select className="form-control" id="location" name="location">
									{!!locations.length ?
						locations.map((location) =>
						<option>{location.name}</option>
					  ) : <option>用戶區域尚未新增任何位置。</option>
					}
                                    </select>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="egg">伺服器引擎</label>
                                    <select className="form-control" id="egg" name="egg">
									{!!eggs.length ?
							eggs.map((egg) =>
							<option>{egg.name}</option>
						  ) : <option>用戶區域尚未新增任何 Egg。</option>
						}
                                    </select>
                                </div>
								{!!eggs.length ?
						!!locations.length ?
						<button type="submit" className="btn btn-primary">繼續</button>
						: <button type="submit" className="btn btn-primary" disabled>繼續</button>
						: <button type="submit" className="btn btn-primary" disabled>繼續</button>
									}
                                <Link to="/dashboard" className="btn btn-dark">取消</Link>
                            </form>
						}
                        </div>
                    </div>
                </div>
		</>
	);
}
