import React from 'react';

export default function FooterAdmin() {
	return (
		<>
			 <footer className="sticky-footer bg-white">
                <div className="container my-auto">
                    <div className="copyright text-left my-auto">
                        <span>版權所有 &copy; 2022 <a href="https://discord.gg/s4thx7c2bs">貓咪托管 | CatHost</a></span>
                    </div>
                </div>
            </footer>
		</>
	);
}
