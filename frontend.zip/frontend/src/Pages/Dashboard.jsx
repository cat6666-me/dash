import React from 'react';
import { useSearchParams } from 'react-router-dom';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import 'sweetalert2/dist/sweetalert2.min.css';

const MySwal = withReactContent(Swal);

import CardServers from '../Components/Cards/CardServers';
import CardInfo from '../Components/Cards/CardInfo';

export default function Dashboard() {
	const [searchParams, setSearchParams] = useSearchParams();
	const generated_password = searchParams.get("generatedpassword")
	if (!generated_password) {
	} else {
		MySwal.fire({
			icon: 'info',
			title: '產生的密碼',
			text: `您用於登入客戶端與遊戲的 Discord 電子郵件產生密碼為 ${generated_password}。請將其記錄在安全的地方。`,
		}).then(() => {
			setSearchParams('')
		})
	}
	return (
		<>
			<div className="row">
					<CardServers />
					<CardInfo />
			</div>
		</>
	);
}
